# OnlyBossHats 🧢

Tienda online de gorras premium.  
Colores: **Negro · Rojo · Blanco**

## Cómo usar

### Opción 1 – Abrir directo (más fácil)
1. Abre la carpeta `public`
2. Haz doble clic en `index.html`
3. ¡Listo! Ya funciona en tu navegador

### Opción 2 – Servidor local (recomendado)
```bash
cd onlybosshats/public
npx serve .
# o
python3 -m http.server 3000
```
Luego abre http://localhost:3000

## Panel de Administración

1. En la web haz clic en el icono de escudo (arriba derecha)
2. Contraseña: **onlyboss2024**
3. Desde ahí puedes:
   - Ver todos los productos
   - Agregar nuevas gorras (con foto, precio, stock, descuento)
   - Editar productos existentes
   - Cambiar stock / marcar Sold Out
   - Eliminar productos

## Secciones de la tienda

| Sección          | Descripción                              |
|------------------|------------------------------------------|
| **Inicio**       | Hero + productos destacados              |
| **Gorras**       | Catálogo completo + filtros              |
| **OnlyBoss Drop**| Ediciones limitadas exclusivas           |
| **Nosotros**     | Historia de la marca                     |
| **Contacto**     | WhatsApp + Instagram                     |

## Carrito y pedidos

- El carrito se guarda en el navegador
- Al finalizar compra se abre WhatsApp con el pedido listo
- **Importante:** cambia el número de WhatsApp en `js/app.js` (busca `5210000000000`)

## Personalizar

- **Contraseña admin:** cambia `ADMIN_PASSWORD` en `js/app.js`
- **Número de WhatsApp:** cambia en la función `checkout()` y en el HTML de contacto
- **Colores:** edita las variables CSS en `css/style.css` (`--red`, `--black`, etc.)
- **Productos de ejemplo:** se cargan la primera vez. Puedes borrarlos desde el admin.

## Notas técnicas

- Todo se guarda en **localStorage** del navegador (no necesita servidor ni base de datos)
- Las fotos se guardan como base64 (ideal para empezar)
- Cuando quieras subirla a internet: Netlify, Vercel, GitHub Pages o cualquier hosting estático
- Más adelante se puede conectar a una base de datos real (Firebase, Supabase, etc.)

---

**OnlyBossHats** — Estilo de jefe. Actitud real.
